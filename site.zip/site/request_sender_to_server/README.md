# Local activation endpoint

Start the site with `npm run dev` in `plainnotes/`. A GET request to
`http://127.0.0.1:5173/activate` runs the workspace-root `activate.sh` on the
same computer. That script starts `program/watch_notes.py` as a background
process. A second request while the process is running returns
`{"status":"already_running"}`. Output goes to `program/watch_notes.log`.

Set `OPENAI_API_KEY` in the environment that starts the site. The script uses
`NOTES_BASE_URL=http://127.0.0.1:5173` by default; override it in that same
environment if the watcher should poll a different notes site. The watcher
needs Python 3.10 or newer. On Windows, Git Bash must be installed at
`C:\Program Files\Git\bin\bash.exe`; on Linux/macOS, `bash` must be on PATH.

The endpoint is available only in the local Vite development server and only
from loopback. It is not a hosted Cloudflare Worker route because Workers
cannot execute local server files.
