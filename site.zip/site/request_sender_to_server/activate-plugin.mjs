import { spawn } from "node:child_process";
import { openSync, closeSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const workspace = fileURLToPath(new URL("..", import.meta.url));
const script = resolve(workspace, "activate.sh");
const log = resolve(workspace, "program", "watch_notes.log");
const loopback = new Set(["127.0.0.1", "::1", "::ffff:127.0.0.1"]);
const hosts = new Set(["127.0.0.1", "localhost", "::1"]);

function respond(response, status, body) {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  });
  response.end(JSON.stringify(body));
}

export function activatePlugin() {
  let child = null;
  return {
    name: "local-activate",
    apply: "serve",
    configureServer(server) {
      server.middlewares.use((request, response, next) => {
        if (request.url?.split("?")[0] !== "/activate") return next();
        if (request.method !== "GET") {
          response.setHeader("Allow", "GET");
          return respond(response, 405, { error: "Use GET /activate." });
        }

        let url;
        try {
          url = new URL(request.url, `http://${request.headers.host}`);
        } catch {
          return respond(response, 403, { error: "Local access only." });
        }
        if (
          !loopback.has(request.socket.remoteAddress ?? "") ||
          !hosts.has(url.hostname) ||
          (request.headers.origin && request.headers.origin !== url.origin) ||
          (request.headers["sec-fetch-site"] &&
            !["same-origin", "none"].includes(request.headers["sec-fetch-site"]))
        ) {
          return respond(response, 403, { error: "Local access only." });
        }
        if (child && child.exitCode === null) {
          return respond(response, 200, { status: "already_running" });
        }
        if (!process.env.OPENAI_API_KEY?.trim()) {
          return respond(response, 503, { error: "Set OPENAI_API_KEY in the site server environment before activation." });
        }

        let fd;
        try {
          mkdirSync(dirname(log), { recursive: true });
          fd = openSync(log, "a");
          const bash = process.platform === "win32"
            ? "C:\\Program Files\\Git\\bin\\bash.exe"
            : "bash";
          child = spawn(bash, [script], {
            cwd: workspace,
            detached: true,
            windowsHide: true,
            stdio: ["ignore", fd, fd],
          });
        } catch (error) {
          if (fd !== undefined) closeSync(fd);
          return respond(response, 500, { error: `Could not start activate.sh: ${error.message}` });
        }
        closeSync(fd);
        const started = child;
        started.once("error", (error) => {
          if (child === started) child = null;
          if (!response.headersSent) respond(response, 500, { error: `Could not start activate.sh: ${error.message}` });
        });
        started.once("spawn", () => {
          started.unref();
          if (!response.headersSent) respond(response, 202, { status: "activation_requested", log });
        });
        started.once("exit", () => {
          if (child === started) child = null;
        });
      });
    },
  };
}
