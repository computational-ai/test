import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import watch_notes as watcher


class WatcherTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.db = sqlite3.connect(self.root / "state.sqlite3")
        self.db.row_factory = sqlite3.Row
        self.addCleanup(self.db.close)
        watcher.init_db(self.db)

    def test_pagination_order_restarts_and_colliding_titles(self):
        old = {"id": "aaaaaaaaaaaa", "title": "same/title", "content": "first", "createdAt": "2026-10-20T00:00:00.000Z"}
        new = {"id": "bbbbbbbbbbbb", "title": "same/title", "content": "second", "createdAt": "2026-10-21T00:00:00.000Z"}
        pages = [
            {"notes": [new], "nextCursor": "2026-10-21T00:00:00.000Z|bbbbbbbbbbbb"},
            {"notes": [old], "nextCursor": None},
        ]
        with patch.object(watcher, "get_json", side_effect=pages) as fetch:
            self.assertEqual(watcher.sync_notes(self.db, "https://example.test"), 2)
            self.assertIn("cursor=", fetch.call_args_list[1].args[0])
        handled = []

        def answer(note, *_args):
            handled.append(note["id"])
            return note["content"].upper()

        output = self.root / "server_response"
        output.mkdir()
        with patch.object(watcher, "answer_note", side_effect=answer):
            watcher.process_pending(self.db, output, "key", "https://api.example", 2, False)
        self.assertEqual(handled, [old["id"], new["id"]])
        self.assertEqual((output / "same-title").read_text(), "FIRST\n")
        self.assertEqual((output / "same-title--bbbbbbbbbbbb").read_text(), "SECOND\n")
        with patch.object(watcher, "get_json", return_value={"notes": [new], "nextCursor": None}) as fetch:
            self.assertEqual(watcher.sync_notes(self.db, "https://example.test"), 0)
            self.assertEqual(fetch.call_count, 1)
        self.assertEqual(self.db.execute("SELECT count(*) FROM notes WHERE status='pending'").fetchone()[0], 0)

    def test_new_note_with_same_timestamp_after_known_note(self):
        stamp = "2026-10-21T00:00:00.000Z"
        known = {"id": "bbbbbbbbbbbb", "title": "known", "content": "x", "createdAt": stamp}
        new = {"id": "aaaaaaaaaaaa", "title": "new", "content": "y", "createdAt": stamp}
        self.db.execute("INSERT INTO notes (id,title,content,created_at) VALUES (?,?,?,?)", tuple(known[k] for k in ("id", "title", "content", "createdAt")))
        self.db.execute("INSERT INTO metadata VALUES ('initialized','1')")
        self.db.commit()
        pages = [
            {"notes": [known], "nextCursor": f"{stamp}|{known['id']}"},
            {"notes": [new], "nextCursor": None},
        ]
        with patch.object(watcher, "get_json", side_effect=pages):
            self.assertEqual(watcher.sync_notes(self.db, "https://example.test"), 1)
        self.assertIsNotNone(self.db.execute("SELECT id FROM notes WHERE id=?", (new["id"],)).fetchone())

    def test_failed_scan_does_not_skip_older_new_notes(self):
        old = {"id": "aaaaaaaaaaaa", "title": "old", "content": "x", "createdAt": "2026-10-20T00:00:00.000Z"}
        self.db.execute("INSERT INTO notes (id,title,content,created_at) VALUES (?,?,?,?)", tuple(old[k] for k in ("id", "title", "content", "createdAt")))
        self.db.execute("INSERT INTO metadata VALUES ('initialized','1')")
        self.db.commit()
        new = {"id": "bbbbbbbbbbbb", "title": "new", "content": "y", "createdAt": "2026-10-21T00:00:00.000Z"}
        page = {"notes": [new], "nextCursor": "more"}
        with patch.object(watcher, "get_json", side_effect=[page, RuntimeError("network error")]):
            with self.assertRaisesRegex(RuntimeError, "network error"):
                watcher.sync_notes(self.db, "https://example.test")
        self.assertIsNone(self.db.execute("SELECT id FROM notes WHERE id=?", (new["id"],)).fetchone())

    def test_model_loop_uses_requested_model_and_continuation(self):
        note = {"title": "question", "content": "What is 2+2?"}
        responses = [
            {"id": "resp_1", "status": "completed", "output": [{"type": "message", "content": [{"type": "output_text", "text": "Four."}]}]},
            {"id": "resp_2", "status": "completed", "output": [{"type": "message", "content": [{"type": "output_text", "text": "4."}]}]},
        ]
        with patch.object(watcher, "get_json", side_effect=responses) as fetch:
            self.assertEqual(watcher.answer_note(note, "key", "https://api.example", 2, True), "4.")
            self.assertEqual(fetch.call_args_list[0].kwargs["data"]["model"], "gpt-6-sol")
            self.assertEqual(fetch.call_args_list[0].kwargs["data"]["tools"], [{"type": "web_search"}])
            self.assertEqual(fetch.call_args_list[1].kwargs["data"]["previous_response_id"], "resp_1")


if __name__ == "__main__":
    unittest.main()
