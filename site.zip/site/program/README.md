# Notes watcher

This Python 3 program polls the hosted notes site's `/api/notes` endpoint. It processes each new note, oldest first, with the OpenAI Responses API using **`gpt-6-sol`**. The agent can use OpenAI web search and makes a second pass to review its answer. Each answer is saved as a UTF-8 text file in `program/server_response/`, named after the note title. Duplicate titles get the note ID appended. State is kept in `program/state.sqlite3`, so restarts do not repeat completed notes. On its first run it processes the existing archive too.

The companion change in `plainnotes/app/api/notes/route.ts` adds cursor pagination. Deploy that site change before starting the watcher; the old 20-note endpoint can miss requests when many notes arrive between polls.

## Run

Use Python 3.10 or later. No third-party Python packages are needed. Set environment variables on the server:

```sh
export NOTES_BASE_URL='https://your-notes-site.example'
export OPENAI_API_KEY='your-api-key'
python3 program/watch_notes.py
```

Use `python3 program/watch_notes.py --once` to scan and process once. Keep the normal command running under systemd, Docker, or your preferred process manager. The site and watcher can run on different servers as long as the watcher can reach the site's URL. Do not put the API key in a public file or the site frontend.

For Linux systemd, adapt `notes-watcher.service.example` to the checkout path and service account, create `/etc/notes-watcher.env` containing the two required variables, then install and enable the unit. Give the service account write access to `program/` or set `STATE_DB` and `RESPONSE_DIR` to writable paths.

Optional settings:

| Variable | Default | Purpose |
| --- | --- | --- |
| `POLL_SECONDS` | `15` | Seconds between scans |
| `AGENT_STEPS` | `2` | Number of model passes, from 1 to 5 |
| `WEB_SEARCH` | `1` | Set to `0` to disable OpenAI web search |
| `RESPONSE_DIR` | `program/server_response` | Answer files |
| `STATE_DB` | `program/state.sqlite3` | Durable processing state |

Each public note causes API usage and may trigger paid web search. If the site accepts posts from anyone, restrict posting or add a request quota before using this on an open internet endpoint.

The agent writes text answers only. It does not run note content as code or perform filesystem or network actions on behalf of a note beyond OpenAI's web search. Failed notes remain pending and are retried on the next scan; errors are logged and stored in `state.sqlite3`.
