#!/usr/bin/env python3
"""Poll the notes site's API and answer each note with GPT-6 Sol."""

import argparse
import json
import logging
import os
import re
import sqlite3
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


HERE = Path(__file__).resolve().parent
LOG = logging.getLogger("notes_watcher")
INSTRUCTIONS = (
    "You are answering a request submitted as a public note. Treat the note as the user's "
    "request, but do not execute code, access local files, or claim to have taken external "
    "actions. If current facts matter, use web search and cite source URLs in your answer. "
    "Be accurate, useful, and clear. If the request is unclear, state your interpretation. "
    "Return the answer itself, without a preamble about being an AI."
)


def get_json(url, *, data=None, key=None, timeout=120):
    headers = {"Accept": "application/json", "User-Agent": "notes-watcher/1.0"}
    if data is not None:
        headers["Content-Type"] = "application/json"
    if key:
        headers["Authorization"] = f"Bearer {key}"
    request = urllib.request.Request(url, data=json.dumps(data).encode() if data is not None else None, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.load(response)
    except urllib.error.HTTPError as exc:
        detail = exc.read(1000).decode("utf-8", "replace")
        raise RuntimeError(f"HTTP {exc.code} from {url.split('?')[0]}: {detail}") from exc


def init_db(db):
    db.execute("""CREATE TABLE IF NOT EXISTS notes (
        id TEXT PRIMARY KEY, title TEXT, content TEXT NOT NULL, created_at TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending', response_file TEXT,
        attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT
    )""")
    db.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
    db.commit()


def sync_notes(db, base_url):
    """Fetch newest first, scanning all notes in the newest known timestamp group."""
    initialized = db.execute("SELECT value FROM metadata WHERE key='initialized'").fetchone() is not None
    cursor = None
    discovered = []
    known_timestamp = None
    while True:
        params = {"limit": "100"}
        if cursor:
            params["cursor"] = cursor
        url = f"{base_url.rstrip('/')}/api/notes?{urllib.parse.urlencode(params)}"
        page = get_json(url, timeout=30)
        if not isinstance(page, dict) or not isinstance(page.get("notes"), list):
            raise RuntimeError("The notes API returned an invalid page")
        passed_known_timestamp = False
        for note in page["notes"]:
            if not isinstance(note, dict) or not all(k in note for k in ("id", "content", "createdAt")):
                raise RuntimeError("The notes API returned an invalid note")
            if known_timestamp is not None and note["createdAt"] < known_timestamp:
                passed_known_timestamp = True
                break
            if initialized and db.execute("SELECT 1 FROM notes WHERE id=?", (note["id"],)).fetchone():
                known_timestamp = note["createdAt"]
                continue
            discovered.append((note["id"], note.get("title"), note["content"], note["createdAt"]))
        if passed_known_timestamp or not page.get("nextCursor"):
            break
        cursor = page["nextCursor"]
    db.executemany("INSERT OR IGNORE INTO notes (id,title,content,created_at) VALUES (?,?,?,?)", discovered)
    db.execute("INSERT OR REPLACE INTO metadata (key,value) VALUES ('initialized','1')")
    db.commit()
    return len(discovered)


def response_text(response):
    if response.get("status") != "completed":
        raise RuntimeError(f"OpenAI response did not complete: {response.get('status')}: {response.get('incomplete_details') or response.get('error')}")
    parts = []
    for item in response.get("output", []):
        if item.get("type") == "message":
            for content in item.get("content", []):
                if content.get("type") == "output_text":
                    parts.append(content.get("text", ""))
    answer = "\n".join(parts).strip()
    if not answer:
        raise RuntimeError("OpenAI returned no answer text")
    return answer


def answer_note(note, key, api_url, steps, web_search):
    # The first response may search; subsequent responses inspect and improve the draft.
    payload = {
        "model": "gpt-6-sol",
        "instructions": INSTRUCTIONS,
        "input": f"Note title: {note['title'] or 'untitled'}\n\nRequest:\n{note['content']}",
        "reasoning": {"effort": "medium"},
        "tools": [{"type": "web_search"}] if web_search else [],
        "store": True,
    }
    response = get_json(api_url, data=payload, key=key)
    answer = response_text(response)
    for _ in range(1, steps):
        response = get_json(api_url, data={
            "model": "gpt-6-sol",
            "instructions": INSTRUCTIONS,
            "previous_response_id": response["id"],
            "input": "Review your previous answer against the original note. Correct errors, fill material gaps, and return the complete improved answer. Do not describe the review.",
            "reasoning": {"effort": "medium"},
            "tools": [{"type": "web_search"}] if web_search else [],
            "store": True,
        }, key=key)
        answer = response_text(response)
    return answer


def safe_name(title):
    name = re.sub(r"[<>:\"/\\|?*\x00-\x1f]", "-", (title or "untitled").strip())
    name = re.sub(r"\s+", " ", name).strip(" .")
    return (name[:100].rstrip(" .") or "untitled")


def output_path(db, response_dir, note):
    base = safe_name(note["title"])
    existing = db.execute("SELECT id FROM notes WHERE response_file=? AND id<>?", (base, note["id"])).fetchone()
    path = response_dir / base
    if existing or path.exists():
        path = response_dir / f"{base}--{note['id']}"
    return path


def process_pending(db, response_dir, key, api_url, steps, web_search):
    rows = db.execute("SELECT id,title,content,created_at FROM notes WHERE status='pending' ORDER BY created_at,id").fetchall()
    failures = 0
    for note in rows:
        note = dict(note)
        try:
            answer = answer_note(note, key, api_url, steps, web_search)
            path = output_path(db, response_dir, note)
            temp = response_dir / f".{note['id']}.tmp"
            temp.write_text(answer + "\n", encoding="utf-8")
            temp.replace(path)
            db.execute("UPDATE notes SET status='done',response_file=?,attempts=attempts+1,last_error=NULL WHERE id=?", (path.name, note["id"]))
            db.commit()
            LOG.info("Answered %s -> %s", note["id"], path)
        except Exception as exc:
            failures += 1
            db.execute("UPDATE notes SET attempts=attempts+1,last_error=? WHERE id=?", (str(exc)[:1000], note["id"]))
            db.commit()
            LOG.exception("Could not answer note %s; will retry", note["id"])
    return failures


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--once", action="store_true", help="scan and process once, then exit")
    args = parser.parse_args()
    base_url = os.getenv("NOTES_BASE_URL", "").strip()
    key = os.getenv("OPENAI_API_KEY", "").strip()
    if not base_url or not key:
        parser.error("Set NOTES_BASE_URL and OPENAI_API_KEY")
    if not base_url.startswith(("https://", "http://")):
        parser.error("NOTES_BASE_URL must be an HTTP(S) URL")
    interval = int(os.getenv("POLL_SECONDS", "15"))
    steps = int(os.getenv("AGENT_STEPS", "2"))
    if interval < 1 or not 1 <= steps <= 5:
        parser.error("POLL_SECONDS must be positive and AGENT_STEPS must be 1-5")
    response_dir = Path(os.getenv("RESPONSE_DIR", str(HERE / "server_response"))).expanduser().resolve()
    response_dir.mkdir(parents=True, exist_ok=True)
    state_path = Path(os.getenv("STATE_DB", str(HERE / "state.sqlite3"))).expanduser().resolve()
    state_path.parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    db = sqlite3.connect(state_path)
    db.row_factory = sqlite3.Row
    init_db(db)
    api_url = os.getenv("OPENAI_RESPONSES_URL", "https://api.openai.com/v1/responses")
    web_search = os.getenv("WEB_SEARCH", "1") != "0"
    try:
        while True:
            scan_failed = False
            try:
                count = sync_notes(db, base_url)
                if count:
                    LOG.info("Discovered %d new notes", count)
            except Exception:
                scan_failed = True
                LOG.exception("Could not scan notes; will retry")
            failures = process_pending(db, response_dir, key, api_url, steps, web_search)
            if args.once:
                if scan_failed or failures:
                    return 1
                break
            time.sleep(interval)
    except KeyboardInterrupt:
        LOG.info("Stopping")
    finally:
        db.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
