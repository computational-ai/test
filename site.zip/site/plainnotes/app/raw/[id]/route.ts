import { eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { notes } from "../../../db/schema";

export const dynamic = "force-dynamic";
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[a-f0-9]{12}$/.test(id)) return new Response("Not found", { status: 404 });
  const [note] = await getDb().select().from(notes).where(eq(notes.id, id)).limit(1);
  if (!note) return new Response("Not found", { status: 404 });
  return new Response(note.content, { headers: { "Content-Type": "text/plain; charset=utf-8", "X-Content-Type-Options": "nosniff", "Cache-Control": "public, max-age=300" } });
}
