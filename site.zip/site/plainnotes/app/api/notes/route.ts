import { and, desc, eq, lt, or } from "drizzle-orm";
import { getDb } from "../../../db";
import { notes } from "../../../db/schema";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const requestedLimit = Number(url.searchParams.get("limit") ?? "20");
  const limit = Number.isSafeInteger(requestedLimit) && requestedLimit >= 1 && requestedLimit <= 100 ? requestedLimit : 20;
  const cursor = url.searchParams.get("cursor");
  let before: { createdAt: string; id: string } | null = null;
  if (cursor !== null) {
    const match = /^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z)\|([a-f0-9]{12})$/.exec(cursor);
    if (!match) return Response.json({ error: "Invalid cursor." }, { status: 400 });
    before = { createdAt: match[1], id: match[2] };
  }
  const query = getDb().select().from(notes);
  const filtered = before
    ? query.where(or(lt(notes.createdAt, before.createdAt), and(eq(notes.createdAt, before.createdAt), lt(notes.id, before.id))))
    : query;
  const rows = await filtered.orderBy(desc(notes.createdAt), desc(notes.id)).limit(limit + 1);
  const recent = rows.slice(0, limit);
  const last = recent.at(-1);
  return Response.json({ notes: recent, nextCursor: rows.length > limit && last ? `${last.createdAt}|${last.id}` : null }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  let input: unknown;
  try { input = await request.json(); } catch { return Response.json({ error: "Invalid request." }, { status: 400 }); }
  if (!input || typeof input !== "object") return Response.json({ error: "Invalid request." }, { status: 400 });
  const { title, content } = input as { title?: unknown; content?: unknown };
  if (typeof content !== "string" || !content.trim() || content.length > 20000 || typeof title !== "string" || title.length > 120) {
    return Response.json({ error: "Add some text (up to 20,000 characters)." }, { status: 400 });
  }
  const note = { id: crypto.randomUUID().replace(/-/g, "").slice(0, 12), title: title.trim() || null, content, createdAt: new Date().toISOString() };
  await getDb().insert(notes).values(note);
  return Response.json({ note }, { status: 201, headers: { "Cache-Control": "no-store" } });
}
