"use client";

import { useState } from "react";

type Note = { id: string };

export default function Home() {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function post(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!content.trim() || busy) return;
    setBusy(true);
    setMessage("");
    try {
      const response = await fetch("/api/notes", {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ title, content }),
      });
      const data = await response.json() as { error?: string; note: Note };
      if (!response.ok) throw new Error(data.error || "Could not post note.");
      window.location.href = `/n/${data.note.id}`;
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not post note.");
      setBusy(false);
    }
  }

  return <main className="shell">
    <header className="topline"><a className="brand" href="/">notes<span>.</span></a><a className="navlink" href="/notes">view notes ↗</a></header>
    <section className="intro"><p className="eyebrow">/ new paste</p><h1>Put a thought somewhere.</h1><p>Write anything in text. Post it, then share the link.</p></section>
    <form className="editor" onSubmit={post}>
      <label htmlFor="title">title <span>(optional)</span></label>
      <input id="title" name="title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} placeholder="untitled" autoComplete="off" />
      <div className="textareahead"><label htmlFor="content">text</label><span>{content.length.toLocaleString()} / 20,000</span></div>
      <textarea id="content" name="content" value={content} onChange={(e) => setContent(e.target.value)} maxLength={20000} placeholder="Start typing here..." required spellCheck={false} />
      <div className="formbottom"><span className="hint">Posts are public and appear in /notes.</span><button type="submit" disabled={busy || !content.trim()}>{busy ? "posting..." : "post note ↗"}</button></div>
      {message && <p className="error" role="alert">{message}</p>}
    </form>
    <footer>notes. / just text</footer>
  </main>;
}
