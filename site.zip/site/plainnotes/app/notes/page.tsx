import { desc } from "drizzle-orm";
import { getDb } from "../../db";
import { notes } from "../../db/schema";

export const dynamic = "force-dynamic";

function sizeOf(content: string) {
  const bytes = new TextEncoder().encode(content).length;
  return bytes < 1024 ? `${bytes} B` : `${(bytes / 1024).toFixed(1)} KB`;
}

export default async function NotesPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const params = await searchParams;
  const parsed = Number(params.page ?? "1");
  const page = Number.isSafeInteger(parsed) && parsed > 0 && parsed <= 10000 ? parsed : 1;
  const rows = await getDb().select().from(notes).orderBy(desc(notes.createdAt), desc(notes.id)).limit(51).offset((page - 1) * 50);
  const hasMore = rows.length > 50;
  const shown = rows.slice(0, 50);

  return <main className="shell">
    <header className="topline"><a className="brand" href="/">notes<span>.</span></a><a className="navlink" href="/">+ new note</a></header>
    <section className="browseintro"><p className="eyebrow">/ archive</p><h1>Explore notes.</h1><p>Public text, in the order it was posted.</p></section>
    <section className="archive"><div className="sectionhead"><h2>posted notes</h2><span>page {String(page).padStart(2, "0")}</span></div>
      {shown.length === 0 ? <p className="empty">{page === 1 ? <>No notes yet. <a href="/">Post the first one ↗</a></> : "There are no notes on this page."}</p> : <div className="archivewrap"><table><thead><tr><th>name / title</th><th>posted</th><th>size</th></tr></thead><tbody>{shown.map((note) => <tr key={note.id}><td><a href={`/n/${note.id}`}>{note.title || "untitled"}</a></td><td><time dateTime={note.createdAt}>{new Date(note.createdAt).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })}</time></td><td>{sizeOf(note.content)}</td></tr>)}</tbody></table></div>}
      {(page > 1 || hasMore) && <nav className="pagination" aria-label="Archive pages">{page > 1 && <a href={page === 2 ? "/notes" : `/notes?page=${page - 1}`}>← newer</a>}<span>page {page}</span>{hasMore && <a href={`/notes?page=${page + 1}`}>older →</a>}</nav>}
    </section><footer>notes. / just text</footer>
  </main>;
}
