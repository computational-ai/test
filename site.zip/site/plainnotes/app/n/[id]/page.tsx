import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { getDb } from "../../../db";
import { notes } from "../../../db/schema";
import CopyButton from "./copy-button";

export const dynamic = "force-dynamic";

export default async function NotePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[a-f0-9]{12}$/.test(id)) notFound();
  const [note] = await getDb().select().from(notes).where(eq(notes.id, id)).limit(1);
  if (!note) notFound();
  return <main className="shell"><header className="topline"><a className="brand" href="/">notes<span>.</span></a><a className="navlink" href="/notes">view notes ↗</a></header>
    <article className="noteview"><a href="/notes" className="back">← all notes</a><h1>{note.title || "untitled"}</h1><div className="meta">posted {new Date(note.createdAt).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" })} · {note.content.length.toLocaleString()} characters</div>
      <div className="actions"><CopyButton /><a href={`/raw/${note.id}`} target="_blank" rel="noopener noreferrer">view raw ↗</a></div><div className="notecontent">{note.content}</div></article><footer>notes. / just text</footer></main>;
}
