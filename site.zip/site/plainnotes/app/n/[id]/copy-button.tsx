"use client";
import { useState } from "react";
export default function CopyButton() {
  const [copied, setCopied] = useState(false);
  return <button type="button" onClick={async () => { await navigator.clipboard.writeText(window.location.href); setCopied(true); setTimeout(() => setCopied(false), 2000); }}>{copied ? "copied ✓" : "copy link"}</button>;
}
