import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "notes. — plain text sharing",
  description: "Write a note. Post it. Share a permanent link.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
