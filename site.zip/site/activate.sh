#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export NOTES_BASE_URL="${NOTES_BASE_URL:-http://127.0.0.1:5173}"

# Keep one watcher per checkout, including across development-server restarts.
if command -v flock >/dev/null 2>&1; then
  exec 9>"$ROOT/program/.activate.lock"
  flock -n 9 || exit 0
fi

if [[ -n "${PYTHON_BIN:-}" ]]; then
  PYTHON="$PYTHON_BIN"
elif [[ "${OSTYPE:-}" == msys* || "${OSTYPE:-}" == cygwin* ]] && command -v python >/dev/null 2>&1; then
  # Windows' python3 app alias may exist without an installed interpreter.
  PYTHON=python
elif command -v python3 >/dev/null 2>&1; then
  PYTHON=python3
else
  PYTHON=python
fi

exec "$PYTHON" "$ROOT/program/watch_notes.py"
